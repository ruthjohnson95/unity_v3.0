#!/usr/bin/env sh
#$ -cwd
#$ -j y
#$ -l h_data=6G,h_rt=24:00:00,highp
#$ -o unity_profile.log
#$ -t 1-10:1

# This script will profile the long version and DP version with M=10, 100, 1000, 2000

SGE_TASK_ID=1

source /u/local/Modules/default/init/modules.sh
module load python/2.7

MAIN_DIR=/u/home/r/ruthjohn/ruthjohn/unity_v3.0/simulations/benchmark
SRC_DIR=${MAIN_DIR}/src
SCRIPT_DIR=${MAIN_DIR}/scripts
OUTDIR=${MAIN_DIR}
LD_DIR=${MAIN_DIR}/ld_files

for i in 5 25 50 75 100 125
do
    COUNTER=$((COUNTER+1))
    if [[ $COUNTER -eq $SGE_TASK_ID ]]
    then

    SIM_NAME="profile_dp"
    SIGMA_G=0.005
    SIGMA_E=2.8e-06
    P_SIM=0.01
    N=100000
    LD_FILE=${LD_DIR}/chr0.M${i}.ld
    SEED=$SGE_TASK_ID # change seed for each simulation
    ITS=100

    # make simulation dir
  	OUTDIR=${OUTDIR}/${SIM_NAME}
  	mkdir -p $OUTDIR

    # generate sample gwas
	python ${SCRIPT_DIR}/simulate_full.py --sim_name $SIM_NAME --sigma_g $SIGMA_G --sigma_e $SIGMA_E --p_sim $P_SIM   --seed $SEED --ld_file $LD_FILE --outdir $OUTDIR

    # transform betas
    GWAS_FILE=${OUTDIR}/chr$SEED.0.0.gwas
    python ${SCRIPT_DIR}/transform_betas.py --gwas_file $GWAS_FILE --ld_file $LD_FILE

    # take 1/2 power of ld
    LD_BASE_FILE=$(basename $LD_FILE)
    LD_PREFIX=${LD_BASE_FILE%.*}
    LD_HALF_FILE=${OUTDIR}/${LD_PREFIX}.half_ld
    python ${SCRIPT_DIR}/half_ld.py --ld_file $LD_FILE --ld_out $LD_HALF_FILE

    # run inference
    python $SRC_DIR/unity_v3_block.py --seed $SEED  --N $N --id $SIM_NAME --its $ITS --ld_half_file $LD_HALF_FILE --gwas_file $GWAS_FILE  --outdir $OUTDIR --non_inf_var 'n' --dp 'y' --full 'y' --profile 'y'

      fi
done


# Slow version
for i in 5 25 50 75 100 125
do
    COUNTER=$((COUNTER+1))
    if [[ $COUNTER -eq $SGE_TASK_ID ]]
    then

    SIM_NAME="profile_slow"
    SEED=$SGE_TASK_ID # change seed for each simulation
    ITS=100

    # run inference
    python $SRC_DIR/unity_v3_block.py --seed $SEED  --N $N --id $SIM_NAME --its $ITS --ld_half_file $LD_HALF_FILE --gwas_file $GWAS_FILE  --outdir $OUTDIR --non_inf_var 'n' --dp 'n' --full 'y' --profile 'y'

      fi
done
