from unity_metropolis import *
from auxilary import *
import sys
import scipy.sparse as sp
import pandas as pd
import logging

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', level=logging.INFO)


"""
unity_gibbs.py

Describes functions used for sampling from posterior distribution of p.
Models LD in a full Gibbs sampler.

"""


"""calculates the posterior density of c and gamma in block

    Args:
        c_old: causal status vector from prev iteration
        gamma_old: causal effect sizes
        p_old: proportion p
        sigma_g: genetic variance (h/M)
        sigma_e: environmental variance (1-h/N)
        V_half: LD-matrix to half power
        z: gwas effect sizes

    Returns:
        c_t: new estimate of causal vector
        gamma_t: new estimate of effect sizes

"""
def draw_c_gamma(c_old, gamma_old, p_old, sigma_g, sigma_e, V_half, z):

    z = z.reshape(len(z))

    M = len(c_old) # number of SNPs

    # hold new values for c-vector and gamma-vector
    c_t = np.zeros(M)

    gamma_t = np.zeros(M)

    beta_m_old = 100


    # loop through all SNPs
    mu_list = []
    for m in range(0, M):

        # calculate variance term of posterior of gamma, where P(gamma|.) ~ N(mu_m, sigma_m)
        V_m_half = V_half[:, m]

        bottom_sigma_m = 1/float(sigma_g) + (1/float(sigma_e))*(np.matmul(np.transpose(V_m_half), V_m_half))
        sigma_m = 1/float(bottom_sigma_m)

        beta = np.multiply(gamma_old, c_old)
        #print("Beta:")
        #print(beta)

        if m > 0:
            beta_m = beta[m-1]
        else:
            beta_m = 0

        if beta_m_old != beta_m:
            middle_term = np.matmul(V_half, beta)
            #middle_term = sp.coo_matrix.multiply(V_half, beta)


        end_term = np.multiply(V_m_half, gamma_old[m])
        r_m = z - middle_term + end_term

        if m > 0:
            beta_m_old = beta[m]
        else:
            beta_m_old = 10

        # calculate mean term of posterior of gamma, where P(gamma|.) ~ N(mu_m, sigma_m)
        temp_term = np.matmul(np.transpose(r_m), V_m_half)

        mu_m = (sigma_m/float(sigma_e))*temp_term

        mu_list.append(mu_m)

        # calculate params for posterior of c, where P(c|.) ~ Bern(d_m)
        try:
            var_term = math.sqrt(sigma_m/float(sigma_g))
        except:
            print sigma_m
            print sigma_g

        a = 0.50 * 1 / (float(sigma_m)) * mu_m * mu_m

        # check for overflow
        if a > EXP_MAX:
            a = EXP_MAX

        # Bernoulli parameter, where P(c|.) ~ Bern(d_m)
        d_m = (p_old*var_term*math.exp(a))/float(p_old*var_term*math.exp(a) + (1-p_old))

        # draw c_m
        try:
            c_m = st.bernoulli.rvs(d_m)
        except:
            break

        # draw gamma_m
        if c_m == 0:
            gamma_m = 0
        else:
            gamma_m = st.norm.rvs(mu_m, math.sqrt(sigma_m))

        # update values
        c_t[m] = c_m
        gamma_t[m] = gamma_m

        c_old[m] = c_m
        gamma_old[m] = gamma_m

    #print("mu list")
    #print(mu_list)

    return c_t, gamma_t



def draw_p_ivar(c):
    M = len(c)
    alpha1 =  beta_lam + np.sum(c)
    alpha2 = beta_lam + (M - np.sum(c))
    p = st.beta.rvs(alpha1, alpha2)

    return p



def gibbs_ivar_gw(z_list, H_snp, H_gw, N, ld_half_flist, p_init=None, c_init_list=None, gamma_init_list=None, its=5000, non_inf_var=False):

    # hold samples of p
    p_list = []
    gamma_t_list = []
    c_t_list = []

    log_like_list = []

    # initialize params
    if p_init is None:
        p_t = st.beta.rvs(.2, .2)
    else:
        p_t= p_init

    B = len(z_list) # number of blocks

    # loop through all blocks
    for b in range(0, B):

        # read in betas from gwas file
        z_b = z_list[b]
        M_b = len(z_list[b])

        if non_inf_var:
            sd = math.sqrt(H_gw/float(p_t*M_b))
        else:
            sd = math.sqrt(H_snp)

        # save old value to see see if accepted/rejected
        p_old = p_t

        if gamma_init_list is None:
            gamma_t_b = st.norm.rvs(loc=0, scale=sd, size=M_b)
        else:
            gamma_t_b = list(np.multiply(gamma_init_list[b], c_init_list[b]))

        if c_init_list is None:
            c_t_b = st.bernoulli.rvs(p=p_old, size=M_b)
        else:
            c_t_b = list(c_init_list[b])

        # build list of blocks for next iteration
        gamma_t_list.append(gamma_t_b)
        c_t_list.append(c_t_b)

    # end loop initializing first iteration

    for i in range(0, its):
        for b in range(0, B):

            # get params for block b
            z_b = z_list[b]
            M_b = len(z_list[b])

            # read in ld directly from file
            V_half_b = np.loadtxt(ld_half_flist[b])

            # get values from prev iteration
            gamma_t_b = gamma_t_list[b]
            c_t_b = c_t_list[b]

            if non_inf_var: # update sigma_g with new p value
                # DEBUGGING
                #if i == 0:
                #    logging.info("WARNING: USING DEBUGGING MODE OF FIXED P FOR VARIANCE")
                #p_t = 0.01
                sigma_g_b = H_gw/float(p_t*M_b)
            else:
                sigma_g_b = H_snp

            #logging.info("Sigma_g: %.4g" % sigma_g_b)

            sigma_e_b = (1 - H_gw) / N

            # sample causal vector and effects for  block b
            c_t_b, gamma_t_b = draw_c_gamma(c_t_b, gamma_t_b, p_t, sigma_g_b, sigma_e_b, V_half_b, z_b)

            # replace in larger lists
            gamma_t_list[b] = gamma_t_b
            c_t_list[b] = c_t_b

        # end loop over blocks
        p_t = draw_p_ivar_gw(c_t_list)

        sigma_e = (1 - H_gw) / N
        log_like_t = log_like(z_list, gamma_t_list, c_t_list, sigma_e, ld_half_flist)

        # keep running total of log likelihood
        log_like_list.append(log_like_t)

        # add p_t to list
        p_list.append(p_t)

        # print debugging-info
        if i <= 10 or i % 10 == 0:
            print("Iteration %d: sampled p: %.4f, log-like: %4g") % (i, p_t, log_like_t)

    # end loop iterations
    start = int(its*burn)
    p_est = np.mean(p_list[start: ])
    p_var = np.var(p_list[start: ])

    avg_log_like = np.mean(log_like_list[start:])
    var_log_like = np.var(log_like_list[start:])

    return p_est, p_var, p_list, avg_log_like, var_log_like



def gibbs_full(z_list, N, ld_half_flist, p_init=None, c_init_list=None, gamma_init_list=None, its=5000):

    # lists to hold esimtates
    p_list = []
    sigma_g_list = []
    sigma_e_list = []
    log_like_list = []

    # lists to hold latent params
    gamma_t_list = []
    c_t_list = []

    B = len(z_list)

    ####################################
    ##          INITIALIZATION        ##
    ####################################

    # initialize p
    if p_init is None:
        p_t = st.beta.rvs(.2, .2)
    else:
        p_t= p_init

    p_list.append(p_t)

    # initialize sigma_g
    z_arr = np.hstack(np.asarray(z_list))

    sigma_g_t = np.var(np.abs(z_arr))
    # Fixed initalization
    #sigma_g_t = 0.00001
    sigma_g_list.append(sigma_g_t)

    # initialize sigma
    sigma_e_t = (1-sigma_g_t) / float(N)
    sigma_e_list.append(sigma_e_t)

    # initialize c and gamma
    for b in range(0, B):

        # read in betas from gwas file
        z_b = z_list[b]
        M_b = len(z_list[b])

        sd = math.sqrt(sigma_g_t)

        if gamma_init_list is None:
            gamma_t_b = st.norm.rvs(loc=0, scale=sd, size=M_b)
        else:
            gamma_t_b = list(np.multiply(gamma_init_list[b], c_init_list[b]))

        if c_init_list is None:
            c_t_b = st.bernoulli.rvs(p=p_old, size=M_b)
        else:
            c_t_b = list(c_init_list[b])

        # build list of blocks for next iteration
        gamma_t_list.append(gamma_t_b)
        c_t_list.append(c_t_b)

    ####################################
    ##            INFERENCE           ##
    ####################################

    for i in range(0, its):
        for b in range(0, B):

            # get params for block b
            z_b = z_list[b]
            M_b = len(z_b)
            V_half_b = np.loadtxt(ld_half_flist[b])

            # get values from previous iteration
            gamma_t_b = gamma_t_list[b]
            c_t_b = c_t_list[b]

            # sample c, gamma
            c_t_b, gamma_t_b = draw_c_gamma(c_t_b, gamma_t_b, p_t, sigma_g_t, sigma_e_t, V_half_b, z_b)

            # replace after sample
            gamma_t_list[b] = gamma_t_b
            c_t_list[b] = c_t_b

        # sample global params

        # sample p
        p_t = draw_p_ivar_gw(c_t_list)
        p_list.append(p_t)

        # sample sigma_g
        sigma_g_t = draw_sigma_g(gamma_t_list, c_t_list)
        sigma_g_list.append(sigma_g_t)

        # sample sigma_e
        sigma_e_t = draw_sigma_e(z_list, gamma_t_list, c_t_list)
        sigma_e_list.append(sigma_e_t)

        # calculate likelihood
        log_like_t = log_like(z_list, gamma_t_list, c_t_list, sigma_e_t, ld_half_flist)
        log_like_list.append(log_like_t)

        # print debugging-info
        if i <= 10 or i % 10 == 0:
            print("Iteration %d: p: %.4f, sigma_g: %.4g, sigma_e: %.4g, log-like: %4g") % (i, p_t, sigma_g_t, sigma_e_t, log_like_t)
            sys.stdout.flush()
            
    # compute averages
    start = int(its*burn)
    p_est = np.mean(p_list[start: ])
    p_var = np.var(p_list[start: ])
    sigma_g_est = np.mean(sigma_g_list[start:])
    sigma_g_var = np.var(sigma_g_list[start:])
    sigma_e_est = np.mean(sigma_e_list[start:])
    sigma_e_var = np.var(sigma_e_list[start:])
    avg_log_like = np.mean(log_like_list[start:])
    var_log_like = np.var(log_like_list[start:])

    return p_est, p_var, sigma_g_est, sigma_g_var, sigma_e_est, sigma_e_var, avg_log_like, var_log_like


def draw_p_ivar_gw(c_t_list):

    c_t_list = np.asarray(c_t_list)
    c_t_list = np.hstack(c_t_list)
    M = np.asarray(c_t_list).size

    alpha1 = beta_lam_1 + np.sum(c_t_list)
    alpha2 = beta_lam_2 + (M - np.sum(c_t_list))
    try:
        p = st.beta.rvs(alpha1, alpha2)
    except:
        print c_t_list

    return p


def draw_sigma_g(gamma_t_list, c_t_list):
    c_t_arr = np.hstack(np.asarray(c_t_list))
    M_c = np.sum(c_t_arr)
    alpha_g = alpha_g0 + (0.50)*M_c

    gamma_t_arr = np.hstack(np.asarray(gamma_t_list))
    gamma_square_sum = np.sum(np.square(gamma_t_arr))
    beta_g = beta_g0 + (0.50)*gamma_square_sum

    sigma_g_t = st.invgamma.rvs(a=alpha_g, scale=beta_g)

    return sigma_g_t


def draw_sigma_e(z_list, gamma_t_list, c_t_list):
    c_t_arr = np.hstack(np.asarray(c_t_list))
    gamma_t_arr = np.hstack(np.asarray(gamma_t_list))
    z_arr = np.hstack(np.asarray(z_list))
    M_gw = len(c_t_arr)
    alpha_e = alpha_e0 + (0.50)*M_gw

    gamma_sum = 0
    nonzero_inds = np.nonzero(c_t_arr)[0]
    for i in nonzero_inds:
        gamma_sum += (z_arr[i] - gamma_t_arr[i]) * (z_arr[i] - gamma_t_arr[i])

    beta_e = beta_e0 + (0.50)*gamma_sum

    sigma_e_t = st.invgamma.rvs(a=alpha_e, scale=beta_e)

    return sigma_e_t


def log_like(z_list, gamma_t_list, c_t_list, sigma_e, V_half_flist):
    total_log_like = 0

    for z, gamma_t, c_t, V_half_fname in zip(z_list, gamma_t_list, c_t_list, V_half_flist):
        V_half = np.loadtxt(V_half_fname)
        M = len(z)
        mu = np.matmul(V_half, np.multiply(gamma_t, c_t))
        cov = np.eye(M)*sigma_e
        log_like = st.multivariate_normal.logpdf(z, mu, cov)
        total_log_like += log_like

    return total_log_like
