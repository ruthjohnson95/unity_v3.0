library("optparse")
 
option_list = list(
  make_option(c("--wgt_file"), type="character", default=NULL, 
              help="full path to FUSION weight matrix", metavar="character"),
	make_option(c("--N"), type="integer",
              help="sample size", metavar="character"),
	make_option(c("--outdir"), type="character",
          help="output directory for resulting locus file", metavar="character")
); 
 
opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);

# read in command line args 
wgt_file <- opt$wgt_file
N <- opt$N 
outdir <- opt$outdir

# load data into workspace 
load(wgt_file) # weight matrix 

# relabel zscores 
zscores <- data.frame(V2=rownames(wgt.matrix), Z=wgt.matrix[,"top1"])

# merge witih the SNP (ie allele and bp) data
final <- merge(snps, zscores, by="V2")

# convert zscore to standardized betas 
final['BETA_STD'] <- final$Z / sqrt(N)

# reorder by BP
locus <- final[order(final$V4),]

# add heading 
colnames(locus) <- c("SNP", "CHR", "drop","BP", "A1", "A2", "Z", "BETA_STD")
keep <- c("SNP", "CHR", "BP", "A1", "A2", "Z", "BETA_STD")
final_locus = locus[keep]


# write to locus file 
gene_prefix <- strsplit(basename(wgt_file),".wgt.RDat")
locus_fname <- paste(gene_prefix, 'locus', sep='.')
full_locus_fname <- file.path(outdir, locus_fname)

# GTEx.Whole_Blood.ENSG00000273281.1.RP11-339B21.14.wgt.RDat 
write.table(x=final_locus, file=full_locus_fname, row.names=F, quote=F)

# save heritability 
H=hsq[1] # get heritability from hsq object (only want first entry; second entry is stand_err)
h_fname <- paste(gene_prefix,'H', sep='.')
full_h_fname <- file.path(outdir, h_fname)
write.table(x=H,file=full_h_fname, row.names=F, quote=F, col.names=F)



