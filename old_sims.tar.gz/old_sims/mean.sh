#!/usr/bin/env bash

DIR=$1

OUTFILE="varyP_summary.txt"
echo "P p sd" > ${DIR}/$OUTFILE

for P in 0.01 0.025 0.05 0.10 0.25
do
    summary_file=${DIR}/summaryP${P}.txt
    
    p=$(Rscript mean.R $summary_file 2>&1 | head -n 1  | cut -d' ' -f2)

    sd=$(Rscript mean.R $summary_file  2>&1 | head -n 2  | cut -d' ' -f3)

    echo $P $p $sd >> ${DIR}/$OUTFILE 

done