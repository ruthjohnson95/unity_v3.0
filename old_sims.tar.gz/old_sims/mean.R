#!/usr/bin/env Rscript

args = commandArgs(trailingOnly=TRUE)

file <- args[1]

df<-read.table(file, header=T)

print(mean(df$p))
print(mean(df$sd))