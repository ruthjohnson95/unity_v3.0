#!/usr/bin/env bash

RESULTS=$1

    echo "p sd" > $RESULTS/summary.txt
    for file in `ls $RESULTS/*.log`
    do
	P_mean=$(cat $file | grep "Estimate p" | cut -d' ' -f3 )
	SD=$(cat $file | grep "SD p" | cut -d' ' -f3 )
	echo $P_mean $SD >> $RESULTS/summary.txt
    done
